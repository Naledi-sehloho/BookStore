import java.util.ArrayList;
import java.util.Scanner;

class Book{
    //Private instance variables
    private String title;
    private double price;
    //Parameterised Constructor
    public Book(String title, double price) {
        this.title = title;
        this.price = price;
    }
    //Getter Methods
    public String getTitle(){
        return this.title;
    }
    public double getPrice(){
        return this.price;
    }
    //Method overloading:getDetails()
    public String getDetails(){
        return this.title;
    }
    public String getDetails(boolean includePrice){
        if(includePrice){
            return this.title+" - $" + Double.toString(this.price);
        } else {
            return this.title;
        }
    }
public class BookStore {
    // Static utility method
    public static void printLine() {
        System.out.println("--------------------");
    }
     // Main method
    public static void main(String[] args) {
        // ArrayList to store books
        ArrayList<Book> catalogue = new ArrayList<>();

        // Adding three pre-defined books
        catalogue.add(new Book("Clean Code", 45.99));
        catalogue.add(new Book("Effective Java", 55.50));
        catalogue.add(new Book("Design Patterns", 60.00));

        // Display catalogue
        System.out.println("Available Books:");
        catalogue.forEach(book -> System.out.println(book.getDetails(true)));

        // Separator line
        printLine();

        try ( // Scanner for user input
                Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter quantity: ");
            String input = sc.nextLine();
            
            // Convert input to int
            int quantity = Integer.parseInt(input);
            
            // Apply discount logic
            if (quantity > 5) {
                System.out.println("Discount applied.");
            } else {
                System.out.println("No discount.");
            }
        }
    }
}
}
  